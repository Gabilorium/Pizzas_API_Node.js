import config from '../../dbconfig.js'
import sql from 'mssql'
import fs from 'fs'

class PizzaService {
    GetAll = async (top,orderField,sortOrder) =>{
        let returnEntity = null;
        
        try{
            console.log('Estoy en: Pizzaservice.GetAll(top,orderField,sortOrder)')
            let pool = await sql.connect(config);
            let result = await pool.request()
                                    .query('SELECT * FROM Pizzas');
            returnEntity = result.recordset;
        }
        catch (error){
            console.log(error)
        }
        return returnEntity;
    }
    GetByID = async (id) =>{
        let returnEntity = null;
        
        try{
            console.log('Estoy en: Pizzaservice.GetByID(id)')
            let pool = await sql.connect(config);
            let result = await pool.request()
                                    .input('pId', sql.Int, id)
                                    .query('SELECT * FROM Pizzas WHERE Id = @pId;');
            returnEntity = result.recordsets[0][0];
            //console.log(returnEntity)
        }
        catch (error){
            console.log(error)
        }
        //console.log(returnEntity)
        return returnEntity;
        
    }
    Insert = async (pizza) =>{
        let returnEntity = null;
        console.log('Estoy en: Pizzaservice.Insert(pizza)')
        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
                                    .input('pNombre'     , sql.NChar , pizza.Nombre)
                                    .input('pLibreGluten', sql.Bit   , pizza.LibreGluten)
                                    .input('pImporte'    , sql.Float , pizza.Importe)
                                    .input('pDescripcion', sql.NChar , pizza.Descripcion)
                                    .query('INSERT INTO Pizzas(Nombre,LibreGluten,Importe,Descripcion)VALUES(@pNombre, @pLibreGluten, @pImporte, @pDescripcion)');
            returnEntity = result.rowsAffected;
        }
        catch (error){
            console.log(error)
        }
        return returnEntity;
    }
    Update = async (pizza) =>{
        let returnEntity = null;
        console.log('Estoy en: Pizzaservice.Update(pizza)')
        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
                                    .input('pId'         , sql.Int   , pizza.Id)
                                    .input('pNombre'     , sql.NChar , pizza.Nombre)
                                    .input('pLibreGluten', sql.Bit   , pizza.LibreGluten)
                                    .input('pImporte'    , sql.Float , pizza.Importe)
                                    .input('pDescripcion', sql.NChar , pizza.Descripcion)
                                    .query('UPDATE Pizzas SET Nombre = @pNombre,LibreGluten = @pLibreGluten,Importe = @pImporte,Descripcion = @pDescripcion WHERE ID = @pId');
            returnEntity = result.recordsets[0][0];
        }
        catch (error){
            console.log(error)
        }
        return returnEntity;
    }
    Delete = async (id) =>{
        let rowsAffected = 0;
        console.log('Estoy en: Pizzaservice.Delete(id)')
        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
                                    .input('pId', sql.Int, id)
                                    .query('Delete FROM Pizzas WHERE Id = @pId');
            rowsAffected = result.rowsAffected;
        }
        catch (error){
            console.log(error)
        }
        return rowsAffected;
    }
}

export default PizzaService
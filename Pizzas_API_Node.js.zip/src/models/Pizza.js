class Pizza{
    Id;
    Nombre;  
    LibreGluten;
    Importe;
    Descripcion;
    constructor(Nombre,  LibreGluten, Importe, Descripcion) {
        this.Nombre = Nombre;
        this.LibreGluten = LibreGluten;
        this.Importe = Importe;
        this.Descripcion = Descripcion;
    }
}


export default Pizza